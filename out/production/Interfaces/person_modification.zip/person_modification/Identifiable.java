package person_modification;

public interface Identifiable {

    String id();
}
