package telephony;

public interface Browseble {

    void browseWeb();
}
