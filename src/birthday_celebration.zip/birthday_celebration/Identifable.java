package birthday_celebration;

public interface Identifable {

    boolean isFake(String number);
    String getId();
}
