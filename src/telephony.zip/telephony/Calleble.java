package telephony;

public interface Calleble {

    void callNumber();
}
