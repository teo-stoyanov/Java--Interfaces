package person_modification;

public interface Person {

    String getName();

    int getAge();
}
