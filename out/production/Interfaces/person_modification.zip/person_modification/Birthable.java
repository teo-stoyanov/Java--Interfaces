package person_modification;

public interface Birthable {

    String birthday();
}
