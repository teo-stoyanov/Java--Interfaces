package birthday_celebration;

public interface Birthdateble {

    boolean ckeckBirthday(String year);
    String  getBirthdate();
}
