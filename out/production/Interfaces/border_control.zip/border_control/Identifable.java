package border_control;

public interface Identifable {

    boolean isFake(String number);
    String getId();
}
