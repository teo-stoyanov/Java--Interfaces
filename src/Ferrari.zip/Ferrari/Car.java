package Ferrari;

public interface Car {

    String hitBrakes();
    String pushGasPedal();
}
